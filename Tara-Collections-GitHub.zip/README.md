# TARA COLLECTIONS

Premium fashion and jewellery e-commerce application built with React, Vite, Tailwind CSS, Firebase Authentication, Cloud Firestore, Firebase Storage, and Firebase Functions.

## Requirements

- Node.js 18 or newer
- npm
- A Firebase project with Authentication, Cloud Firestore, and Storage enabled
- Firebase CLI for deployment: `npm install -g firebase-tools`

## Run locally

```bash
npm install
npm run dev
```

Vite serves the app at the local URL printed in the terminal (normally `http://localhost:5173`).

## Production build

```bash
npm run build
npm run preview
```

The Vite build output is written to `dist/`.

## Firebase deployment

1. Create/select the Firebase project used by this app.
2. Confirm the Firebase web app configuration in `src/firebase/firebase.js` matches your project.
3. Enable the Firebase products required by the app (Authentication providers, Firestore, and Storage).
4. Review `firestore.rules` and `storage.rules` before deploying. Do not deploy rules without checking that admin-only operations are protected for your own admin UID/claims.
5. Install dependencies and build the frontend:

   ```bash
   npm install
   npm run build
   ```

6. Sign in to Firebase CLI and select the correct project:

   ```bash
   firebase login
   firebase use --add
   ```

7. Deploy the configured Firebase resources:

   ```bash
   firebase deploy
   ```

The Firebase configuration currently expects Hosting files in `dist/`, Firestore rules/indexes, Storage rules, and Cloud Functions in `functions/`.

## GitHub upload

Upload the contents of this folder to the root of a new GitHub repository. Do not upload `node_modules/` or `dist/`; both are generated locally and are excluded by `.gitignore`.

## Important security notes

- Firebase web config values are client-side configuration, not server secrets. Security must be enforced with Firestore/Storage rules and trusted server-side code.
- Never commit service-account JSON files, private keys, `.env` files, or other credentials.
- Review the Firebase rules and Cloud Functions before going live. Test with a non-admin account as well as an admin account.
